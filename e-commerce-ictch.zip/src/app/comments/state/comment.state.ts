

class CommentState {
  comments: Comment[] | null = null;
}

class CommentStateFns {
  // TODO:
}
